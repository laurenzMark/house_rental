<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
include('./db_connect.php');
ob_start();
if(!isset($_SESSION['system'])){
	$system = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
	foreach($system as $k => $v){
		$_SESSION['system'][$k] = $v;
	}
}
ob_end_flush();
?>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo $_SESSION['system']['name'] ?></title>
 	

<?php include('./header.php'); ?>
<?php 
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>

</head>
<style>
	body{
		width: 100%;
	    height: calc(100%);
	    /*background: #007bff;*/
	}
	main#main{
		width:100%;
		height: calc(100%);
		background:white;
	}
	#login-right{
		position: absolute;
		right:0;
		width:40%;
		height: calc(100%);
		background:white;
		display: flex;
		align-items: center;
	}
	#login-left {
    position: absolute;
    left: 0;
    width: 50%;
    height: 100%; /* Full height */
    background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAACBFBMVEX////xYE0AAAD9///vYU3vYUv///7yX03///z6///xYEv//f/zX03yX0/vYUz3///oVj4AAAXY2NjsYk70XVHl5eX14djvYFAAAArwYUPGxsbo6OjvYUfv7+/kXFHmXU7pZEcAHCCioqK4uLjc3NyPkI9fYmEABgB+fn44Ozry9vUQFBgAISjzWEa3UEiGhoZpcm73V0HtbF0AFBhnbG73s6lITEtVV1judWwAEQ6Znp0AABIAGRgADxkAGiMfKCXIzMsVICStuawyNjctKSMAEgCCQj0vNTNVNTOpSTsAIiP518fCx78/MTIAJy+ZSUGxcHkcMygWIhTRWmDkv7VYLCgALSrEpJyXjIc5KTK8UkH4UULpn5f97/L58ujZXUjuloheTkA/SVAAJRjifmOOdW20oaXr5M6lmapDOSnn09FVMz6TTD5tQz7ieW3uuacAGQdcOSh/OjfiblByfnMkPDlSZWGHmZWJNi8vOCc+KBIAIAk4MDnTWE+dSUUZFQnQv7DunJRtal09VEm1gn59W1V2QCyWZlu9mY2thG1BKiHEn5zPeWpUTFa8Wj6dmYuePibXhm09U1ktGRYAAB5NIiVSJxTHSUFbXVLPj3vZ7OGLiHxIOz9eZ1uOZlt8V17KaVzuhIXLoImHOxzatLTe08KigX37xr0yWENnVEGPTFDBg3cWzx7aAAAd4klEQVR4nO2di0Ma157Hhzk8ZoZBkBkYBwYhvETsCAMIQjADaoKKmk3WpI0aoCZpNqkR8zCPvdc8erdp100f97G3bdrb7eOm7u79J/ecGVBQSZsWg+3ybSMIw3A+c875nd/5nd8cMayrrrrqqquuuuqqq6666qqrrrrqqquuuuqqq6666qqrrrrqqquuuuqqq6666qqrrn7jMgZ8yiOIODpcksMSSOFe9BDFM50uymEpnML9GObFAyTodFEOSy5fGMNsvj2v6vVAj4V9Xium70ipDlsA0xOAsKVwfCDQ6bIcjgjCTNr/6cxMxpbAfwOIVvgvbG16iSCw66fOPvhnu9kYxSOdKVa7BMiEamm8WN3SwEczsXDu/I1+yV0ksCgeIhs+YCbqwoy/DtsE6wgW1JXCd2wN/JV4c3LmYUzsp9ltszGEh3ZR9MBoNirPjOZfByAIBZSCuhJ1QgCr563shUVeEmmGX1omzAE8sQMDzBdLztmc329zlsIXiY6U+edJaXaq9OHgsamyJVapxIaHy1KlBAJ4sP6mkVxg3BaLGyr29koytXeUOfIiMSPmX4mfcktVArs3k700N7x0uYR5T6bC6gFGckSiNBSl0+moK4lUYcLV2QL/HPnGzk7zliIJu2Zw9p3JS6tLsavgX/AaIiS0aKAgocUOsNDgr45QHxm4tinG7NisnIaeKrj+7rFVkS1CY5tUWBChYZcwkTR2usSvJIDZUukbbmmtBDLxiRwG/RqilDyxqrNUMV866YSH6JsJU6lOl/lVBDDgKMw89EDbEo7iQWftZVdw5pTGskz6shPwJQJUxYZWmgx2tMivKGAMHJtcROODdRAP1McHvT6cyN7ipArhWC/YIOHILiGpLyQ6WuRXVDi4frOfFxfId07gzdPhUPzWbXG0lBso+DFQtTQQytEOFfbVZQTWCzOrLO8ukiE86Wx+kwhlb5X5/pL1hGzF7GtUD6tVCY0Doc4U9+fImz0zTPOxq7YkHgrvezeSvsF62OLzC2dz5PhntKASgjCcefw6fDcsfCd+blOQLpcc5/O+g8ocGHub5YXq841jjvDdaROtErp+BbEPvxcNaP5k9lRMtFRK904OWg+ulczYVL8gjvg3BhwgcZ+hFEJbw5TkiMoq43Bm6MvLp0WPtPw8iCda+ije9FQ/r63YVi75zNFzbp6BhFb8iPulALMOeGEnO/5gU+Dc1Zx8snWjA5h3fatfsPzx6krch935134eEubwox2DdN5NwSZqS/3uBktx/LYX/33upcf74lubIs++SB33YqF/3bTYMQf+8k90WiE8YcQcBfkh7THdvn4H/5vzRz7gO3Zt06BjFu72ZbB7jxbtmA+3/shHOimfze/VGzPxuUVKENce/wEP/JgTDWCHfbBJ6Zjq36ANDaQThC99hAlDOHRHLiayN9wCz3/7zqWDB4lmAczxxuSmKArfJQYCWAYPZmT/ayjqz1QSOpnWlfXTjIcVn9xJf2X7aWbfMXP2nz28WHkPIfbKhR9r2J2SV1ms8J58MCwyovDFH46HSABqjVRPEj6fw2pzhQFGEgBrjsWQ1vPyonB7ae293gg2ni0c0QlwGJcdWDgxdnOT4zzCv22km0Y1o+vM2HEcye9MBhOhSCDjbahfvywvip6e0ffjIcwn73fwjoD8GeDwY9Zk9n1GZKTY+zPQjWkwMnrz1acffPjvb3mDQ87rJ6aubRVkeWB38QJg/o0zw7xHjL2fjWKOo+jR7LgxH1CUQG++PbbXjQHbkkgtjUBLEv6PS8Mey4IrITeB+AflYVanY07FEyR2xIQKapW9mPnLvpVnHtHDDxfS3j3VAMhtSUNLI1gkTrx5YpG1FLHEYPMxtuTMQ5GiNacvBQnz0QrUAFcqBQ2I86Ox9y5rOZN0Ws7n9h0DqrxHI4xgoTz2yYmPBb6IBZN7jnElL63qdDwz/LvUUYsKh/AgwHID8iejrEn0rGY/2m8pUB2KEqzDhIy9dXxRlLbJ/dGYcDJ7mhV53ebZ5NGypsDmBSCDJ9+M8T18/6l4AAW69zWzhU9Xp6e/zgwOYpljz5798bpzcH80Jnw3uxoTOb68tXLUhkRXAo8uwLJR5b/KLaY+1uDdVLIg5yEhHo8fy8rpA2IVruCxD2K0RirfHDxaiLnBsUyVojmxvPWnVh6XLZfLWa1+mxM+c/i8mUDkoEsRjsavjIocrX06YTvMEr+ivGl5trrEctTH66GWRtCLZ/N5uVAIYZlUIhLw+nwH+telO8dDl2nOza5uHBXvFGCh3tTzyhLjkYbXfVi4lRXMrP/ww5Uv78ghLHLz5tS5P48dHI0h0cpiRdJ5TMNnWoQ+XrsyvZGro5ROZJ9CNybhOrhQAAtc2qTFJ2E5gH1L8yy3kEt7W5ww0ntnWZQ8zOaDozHXt8l37TGpR3Q/jYb9SbzFUbCmH7kFYcSZzxBfCDzNF/2tozH3/hKtlpdofvM/Zw+p0K8kb++HnMDR7r9moMssyy2O0mOJswxNjdiGvMQzmueE4kviTeAetMyMAVrmc52vRSMWuslxtFCeyhkjeCrZihDDEluMTqr60z7ymSRI0nYOz7U6lMC8A8HrMYlhy099WKfdGzK6qOGFzz4Pu5K9CWNqsMVhgAhOPr2xeiUACVcXn1Uq9tnW0RijCyLeta/xHpa51enIIgG+FHXidADzD82MXyeSe33N3QMTExvzcn6o12E8dnIsvg4niy0HPHI8ivn6klcrFkb8eKDDiIRxQaRWfRgYxx1V98WVlit/RnSsy+bPuYyOcTjeh6Kplr6n/vG5O5gvvfJ8WeKod8921kcFwG754Dk0JJ+MfWFhShPtWfnzuu8nyNnsiq1qWfow3tlVDBJzPX5uNhKQcFOK2Sbak8z1iYWeDoLZoY3nC55i65b/WgRgLRqNgMC+POaWYn65PRl5AQ8traZIx9Dvn9uN0VZj7OsSMAJAwkHjPEPHXuRb+SmvpkgZzqD6Ui7rUB66SQNtOecvVkLWaJncUHsIQ24TPzoOHVe/LOfqrbTTPmpiktbGZofaY9oRYcyGnB7/xNCO/xqO1J/BCXfgNUccAZaapDlmtrcthCCB6lB16/yDhTqLFU/XujkZSbceTQ9HAPvTOVoXm8Ud7WhM4SAinMVz6Bd/budLEnJWRQxl4689A9e4ggjH8bZM6cIplXCvW2dMZJWqs+LZyGvvla6VG5DwE9zfijAMwE/Ozw8nVUuzvyFGIspJoh1IE3cNnhJ7IKGzFaEVlwvJlLpegdZo/M7WpsI12G8SRr0DB3U1oJ7/MCPGzpqbaGtyF50bpwUu9iXesti5+EfvpZLJwYl8/o0T8TE8jrcOw7gm+ynudkbuULgtqUZrc+mmvm6TH0LC9/paLjk41p+Njo7GYmWkxY8fRsdaG0OVMCB3yOX2DQyG0TpF80KtP/+Qh4T5loS+9UVJEAQTy7K0RsvTb11qTWh7hAgjHVpG1GM+ZAF86eZGZs0OUz2xzwstTZw3u0hxHKdDic4ULcS+/H3rNmhVCEPJvU0eAK86zwh4X//MP7c+zAixt1tN8TEsM1M2aXZEce+9JJc796hfMN1O7CUEIDRWGy3ir9+Y5tYXtZCwdXJvIN9E6H5vXw3tyjHZL3C3g8E9DUIfycbVlYBEfui1I/pOblJC7Frr5N5A3sM2En6ebN3OfArhyt7ZNPTaagN9OBo/TK8tl4I9yLEnBjEeL5sE97XWqa+hSY7aJdQKH70kl9ur2NKVvSdzJXZyjMORA5I526WcPADhHPhgU3Q7cwIRTrb2FqOTrK6BkP/qJbncGYVwolN5tMkhxYr68KYCBE6UWUjYundEt9ieRsLfvySioxLmO3V7m9Wm1p21ydqH8jFE2DJoBFJTjXWo4S+8pIYCiLB84mjdoxh6EKMhYcspPkjeaLQ0tCf/EsIQtDRseaw98YJ2KfGHlxOGB99n6F1Ck+dlNRSdUwg7He1uVuJzhbBlocKF9xvrkC2feEkNBb+KCezHR4sQpP6mELZcKnLNfM3Qqgw9PT2azbF3Wp8t9XZMWloc6/y6U4PCyTuI8FGu1QGu+BXOw6iClNLi715SQ4OpyrPKB0cryzS8cmcUEbac8zlP/qARIZoIRVOUbvh3L6mhyQTKqz1amcKuiUtlRNjSlfIPpE7V9cHXX1/5r2yu9dnyied+fyB+VDIVFLlCoU1J6r8CvR09QRCNERmAhFnzhQ1ZlvPyzMzMiWNxOMm31o8zGgGm1+vRYQR81BMAT+M4Hs/b1JAFIEnSTAKMRCsIAJ4+HIaPRjPZ9kiGy4oSYqD8UDYop9PpUhQOGwGwl0qllwTAYLHCNaEPuFDOBgDNVwOQAJBms3nc5/ONj/tKBAHPabcXiwsL1Wr1SaWytobCBLH+y1/YIaO+jTmM8Jp5B4f6elEC7AD8D/5EGuodqmt9KJ+Xz5yF1VRQNAiVVJRKpYJQiUQiGoKKRCKBwL17gYwir6rMOILyPX78orhdrY4sIxjI4nZzFOy3vAQlSjzPC6p04hKzTJiN7dxcw1rAByO+XanlggogwVJH7sDSJxRBnJSi5K42kn/Y2NiA5JNQW3NbU+fO3bp1//70p58uLpbLZTfHsrwFWSFR/SmKEISClonq0Wrh6KKFJphlWZMGPoX+AqMzsRWinSHTXFr2ERgwN70IDviGhtfQneqojdmL29vbIyMjsF4ur43evu1mKChUePVBHSMpSguFnAGD5ifJZKkazfsL8DPllzdssMTQJKhmA/Z95YkZ2gCFo3RRQSkuKE1M6TBrsRjHCRYo2MIUURSsF4RTg0AhmwacOuFPFO3pJ9rXD4OyFcVgSXOt6yMWWC3LFQUF9X03rBkLb5EQEM9LkAbhIB4Nw/SYFHEm1MwgicGggKE6fAWkPdJRUrFtzdSPBzDSaC5WRmMMo+sxiKhmYL+HP9H4jQZw2NwoGgKgsiMW+MBxJvRggJRa2I16NDSsNQq+a6pVFmqiDUWucddVw6cNSLWzNL7vYfmRthFm0n5gvDpqkbQGCn0fuvjUKzaqVxI8dQ/8CmhktLWKhoZG29xBdaxQaVsrDSbD+qsaSfDUL/lrIkRfAfsqAkX+elONI8Jv2kY4GMRKlyUto613m0Mn7OmharKogh2DF3SaBkYdSy22LdxWCIIRnoYGoh5o0Zko2NWUfoNAYdcy6DQGeN0FCuEzOgF2TVOtx9XGBTQ0mBiOFkROp2U42EtpoYdDl0vL8BRloGHH5hmRWUK9XOeG1uvyGrRkT5ZHRra3i0Vo3koVkdslNAjcZ21zzQtBbI2nG+JIHMvodNDo1EqOBmeWFikdo5RAR7P0LhYyqVpVOp6G/UlUfBNe4HWUUmJGEEfXIMwyGjP5yy/syP0rGY1ouyH07eoABUdjcllqJizn2kd4sV9gmd2zC55zF7bmFE0pOnfjxqnTH8Prj96lPatPV1dPrao6DTVd1yjjWRz++Jtnz/7xj38sbJcVQpp5hlxc6KmGzQuWbwkSDbYHFQMs8w2EJsHkaVsdyomLPZ5GQk54t4DA5rYUIU/sQn7mDflpPw2bKV2emp+ffyO/qzdUzd8txYSb8yey2WPxbHrjedWCom/09EwfrspbnL5Ue4r39fWl09lsFn58Ammw4B85TEJWMDX0coabuyFJPEVzsLuMjqr95T/e+nxmbpPvFzhqLgXnDy449UAzEDQTQTOSnLXwERHjpyZyDiRvOmT+VtIYRGH4fEBxcwPp8eufzocULxf56FEk5OUipZJx64jUYNsoRnC3k5ATTA3+h6CbC163Kx0mDFsVhpHoB2Z0nJks8xoOvnvgeQopRLhS+y2CO0q3JYGhhmuTYT8+bv/0jVZrbr5e/7akaSZs2xRZThCxJkKKmYoix7rmqMI5rBFtNwewXP4mrRIeNLGZaCJ0DU48L5ZFD10ntCLC+VYjgA/3b1saCKGFYg+P0MRsRdHcnCBcqA36XYDUw1/1BHZn7DuR0m7dVfMV6phw4o4eCglslN+qE2KOk1GsCi1wA+HF7+HEXtl9UG+sWVE4J0YTY0j4vGhpusoC27bxEBKOClxDP9Rq52oRawce7+vD03KmtselNe2tSO6toEroh5PdwL1M5l+g4CR3IohdFuZ2CGE7zREV2A93CGcRIUC30ULtOCxmxdv/8ObIsuhpINQIJjvma8+eWemEfg9hzw7hQADOhjOp+j6I5qGQXWKUWBl6t0+WkS2Vz1w6g2zrHWxN2K1DY7ggh0ujfAOh8Xt51upw/B3qzVqQJhwuscilQZZNbLDnFOeh7agzt4cQjvgtCHG1dIl63sSDBHHbtEOIzzr9/hcvXiws/P2777744ovlmG5rJx/WiOXwELB76oQ5RDiTxtPp9fX1R3O1ZoCn1/sFRufRQbeCa1hFpjmPCOuwPTe2p6PYmkFoIOzxTO4QOswu2Irewp3qfodyAquIkFCpAQduLY26OVaJSsB/BotOmGvM+I30OsDI9LpDqS5IiH08PY1chNMP5wo1wt5EhGEVZ8lgaHSEDVodZcdAe+Jt0CJU4AC7e3bdDqFvIFcahTMbZrikEIbTAayimwzWCX0vTMjfRG4a9NPgpFI393aDwxIeLLiIH07uEvIs8vR4ipuaJEhknlCCYoxtsnM1wh6dUMScibaMiQMhrEI3ETKTV/RKQX3x0CduE2uipZJyzWdhgZ7oJt8m0CAC7V8WH/5scXH64cP792+d+nd7hdXOfaWeVB33YDslfQOPiRoh8JjgzJljDe4GQnDbpDPtBYSElKUIr2FbFhn3E7onrqiRLt/JoUf9aJLjLikZLsk0ABUaEaKhwu97pyEqNx8xL0vauSk1Q0G915uApsJ38rFSh7BPg9scqsMeXgMJAaESYpe5gwg1lGUBvt2WRUY8hC3zpgY7pilPvl8b65xh+9rt2GilSKIhMYKPY8Rl05kbhHHf7DQ8cQ8bEZk6YTKimsrBQiadU16BhPpRHk3JKFY79deScoYcJFwTm5aP66aGtmwDoj1pUwoh3egT7hLCxgqnOqQZbTvqDOEhwmy3sIX9hHrCBQmrkPBcSXkhNYS4oBs0VMhb64RgVDFoiPBcndCBVYQDCTWWKiC8bRkt8Ag20kRIlydv7LhlBIlWEIy2XKSAR2D3W5PckBDbV4cuuU6otO9UHmUAwuYZye8SkmtKe6RYZuqcXclHhYTgYEINI45gzqG23IwBCbf31GHhqdrWbI6cEw5sIJdaT+eTOUBCCKF/8pRqd6z1qL0SJ5cDWJWHhHaFMClnQ3ZST5Bgokbog3VYodRW2lM/DNXhE0tjGkddPZAQhPPtINRDwgVL4xxf6554qq6o+PDeoRDy2MhcZCDvw4i/SxzlLtxSxw5fba7X23v8+PGxsYB5WzTtECZCW2tmYETjvr9OiD1R5tAC65n7q125hihzfKRxbt8g8YmZsLWjIwJokYuWJmvmlp+WVMJ0JgpNrVJmZ7LPt2aRtJRbvqXWISyzE00QX7x4/PjNNz9c3q6YuMkdQtfg0ncAwA4bqdehFVu21AnPFXcIq9J+U6oQVkjC1w5bakSEAtt47rJ8X7UXaMOjUH2x1lkoLPOcDhHagUroJ5ZZjjMYDLS63AJH0nPXlYMHg5jPolkww8p2OeuEQN3kExHeWqgR5rBt8eC1DLECwEQ7bhlCm/zZJU2jV1HOf19SHCZfnxX45XqKmgO/NyIxkB8SGmuEI0pQnBI8HrRqxOrmbqrB+MEERvSLzFXjTgIfPBoS0jXCm9u7hE1dZKeraKk1AqRa37T6qoTaxrw7SGhXlmB9Q1bj8ubO3bqhk7YKb/LknxYB6ojevpxrGXprWi2nFWkTWsX3zD3d3iWke9Z2dzGBhKRKqNtHeEBoViEkXc42hPZdiFBs6uwKoVKqIb95ROr/71oxrY/uXGRMHvn7GuGALJ/u3/zsM+S5TZ9ePbVQvHyhgTAmMuLyzrCCCLd3CUcI1Q20gqKF3Q9Yq0Obtw1/fQFt1GinTQ19gS7Pf39d9drW/eaqQVgcrx0bxZ0LoidfI8wF6mElJaq0IZvNT+qEE1GMjIkazrJQLyEkNDcS6n+UcBTt7Z775fewhCFhiW10DenyzPdFMwkdR++Yn9gWdf3/E1b7kz8dApct57/fJg7Ijw1NEGD5wlNlyQgUYB2OCmieVzIqHqiSP14UKZVw8lxF8byRgb0qii0IS1gAEv5iKYScjm4knL9fJUl0V/mQH2yLHnrRq5YSi6b9dsuZ+wcQ6iEhANUGQnIU4fCjtQV5SAiK6ma7kPBGRfFpxhXCg9YZtVpNrATCuTbcXOKC/nvJvY8QkHo95s3awIJIUfQplzqdckLX9B/yQYQAiyLC/NMnCiGcKpvXUMmFpap6rBcSXm0gxFRsK1ZqQahDhI42DPmoH5ZiQlMrlVerzudOZziT9WPXoamjyt5aKD6S9fvz09WDTpSYwLAF+ZZadDkKCREP61kq1gidpF1UPG9NzyQ8DM3Axvuul4qagwjh4MOU4BVoQ34fqkNitNFz4jfn82fyZ/NZWc7bMLtFR1Hi9MSkEnyfyIec8uTgipJo8pGSaZJIKIYmlCwAsPDndz+498knGW8+BMyKj8Yy4u1xqNk7Ay9KxTKCoYX+Mze+efbNN5ub/3t+2ONmdQd53hqDQtiGO72dCmHjmgFdPr36dS3VxIXZ0SJ3D3UlUQvBJ3Opa1PJ5MpXE4MPHmxsTKjagBrEwIvJ8/KJEyfyM/J7xe3LCIfVCqJbzTgRpSXV0hj6H8zPn5+Zn5+fmflMgobmwKVKA2fHwt423ByFCMkmQlYQpSc1Gw0UQoqj1ho+UvwWvYvyvy6WSvZisYjyTZQ8oFj/Zj+682lzs98i8qhJag0mA1qCU5fiPIiF8gjT08PDaLXq9GrZxPQcnNFAx0q1IvxCoW19ybWmIV9noCpmFI0GwAzsaLGd1lqqKElDzTepxJScphijs9QzgCjBgsJRFC3AIUL5hKDpMSmEBg7lL9C0QfmhUWIwJopXM4ZoiqEPwuuhPNSamWxLWhSyNOZmQnj9Li/spGeh37VaraDmZqDsLFFdpVYzmA5HtEekFszG9tz+FIeGHbqbzd8gspKooxS3WiXUwCowodVfFs4mtLs6NEL6GwK0iTAk2yDhHs+pR+NhtRrIp7YhtF4Pa00HK02r5MYYDpmQkhZTgCDaEhEmcvg9ODWF9fITU85eXehKoMQHmoIGp6dHsTsGltOiiJrBQBlMGi3HqcYIycBLEvPsJVtMvyohluj1bUu6w8suUQgFnZJbhW5PRNlhFKWtZcOpuXEWQTShJefLalrDQil6vG2LawTmSs78EIOzUMMvSUQ7UBTKsFKTrCCMRcnxQxllHg8Ti63V0k2q1e3r16+rORqlElp4I9F6YuQg7/5nCRpkZ6rv2mK5380wHIeS5mrpk7zScAS0LqG+IqqDGlVPrESPOlX1tBTlEdYVOgDVFueOxZRqQZkz1e0FlDpzESocDmNGJWkYLZKiBUV1vdRYC7YPveT+xZ8jozcblwtzE3MXLszNXbt2bW4LPczNvTs1dfMmSsu4oQolqj9V89VrqSYPoabR+N2gb75B6SYffvjm48cvXrywPn9+1W9zotxoVS3zTXaUS+Dt3x2T9J66pUBM1TSnMl64cAFlm5w9e3byz0OPHg0NyfljM3UdUwXdtBO1p3GobFZ5Ojb2l78cPw7/P368t6+vr/ZvIK0oiySrasqqhp5uUsaH2r+nAgDEQkxJuJakpSXlQaR5Ssvcvn271sZQE0PdxYlSNFxKuonNVss3UdJN6pqddTgcPt/sbHNStbfm6dazTWpZ1cH9WdXBdjijByCSxPVKZZcF+mjOixdRGoYSnFdyh0E9SWvnQ60udac3m2khYMb0ZnS7AEGaf6Sn/FqFzBoKzxyYxf7bEARU7m55vd/qq9lN35HcybwN8qtDgzmB5zpckkOSHnhxlCgX/fG/JPHzZDtwt5bXKy/KR8gcEiCWVP9UX27oV/Rnpl5NPhwhWrOd/LMah2zZfGiLAZ/cwc2nX4Pt7vDoRyp/8jF4aFvRG7HO/hVtAIJK5pMXb73j6a9cNjyALjEcNHKH8wW5lK22ZUuHpFd3UQHAdThtKZdFRiaHH7Gt/NuowSHFijrw3+x4WN+lxfqbrcOuuuqqq6666qqrrrrqqquuuuqqq6666qqrrrrqqquuuurq/43+D0ZNhwj2EURWAAAAAElFTkSuQmCC') no-repeat center center; /* Use your Base64 image */
    background-size: cover; /* Ensure the image covers the whole area */
    display: flex;
    align-items: center;
}

	#login-right .card{
		margin: auto;
		z-index: 1
	}
	.logo {
    margin: auto;
    font-size: 8rem;
    background: white;
    padding: .5em 0.7em;
    border-radius: 50% 50%;
    color: #000000b3;
    z-index: 10;
}
div#login-right::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: calc(100%);
    height: calc(100%);
    /*background: #000000e0;*/
}

</style>

<body>


  <main id="main" class=" bg-light">
  		<div id="login-left" class="bg-dark">
  		</div>

  		<div id="login-right" class="bg-light">
  			<div class="w-100">
			<h4 class="text-white text-center"><b><?php echo $_SESSION['system']['name'] ?></b></h4>
			<br>
			<br>
  			<div class="card col-md-8">
  				<div class="card-body">
  					<form id="login-form" >
  						<div class="form-group">
  							<label for="username" class="control-label">Username</label>
  							<input type="text" id="username" name="username" class="form-control">
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label">Password</label>
  							<input type="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  			</div>
  		</div>
   

  </main>

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.href ='index.php?page=home';
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
</script>	
</html>